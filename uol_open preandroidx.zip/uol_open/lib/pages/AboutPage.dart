import 'package:flutter/material.dart';
class AboutPage extends StatelessWidget{
  Widget build(BuildContext context,){
    return Scaffold(
        appBar: AppBar(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset('lib/assets/images/uniLogoLandscapeWhite.jpg',
                fit: BoxFit.contain,
                height: 32.0,
              ),
              Container(
                padding: const EdgeInsets.all(8.0), child: Text('About the Uni'),
              )
            ],
          ),
        ),
        backgroundColor: (Color(0xFFFFFFFF)),
        body: new ListView(
          //mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Card(
                color: Colors.white,
                child: Column(
                    children: <Widget>[
                      SizedBox(
                        height: 180.0,
                        child: Stack(
                          children: <Widget>[
                            Positioned.fill(
                              child: Image.asset('lib/assets/images/inb.jpg',
                                fit: BoxFit.cover,
                              ),
                            ),
                            Positioned(
                              bottom: 16.0,
                              left: 16.0,
                              right: 16.0,
                              child: FittedBox(
                                fit: BoxFit.scaleDown,
                                alignment: Alignment.topLeft,
                                child: Text("Waterfront location, a short walk from the heart of Lincoln's city centre",
                                  style: Theme.of(context)
                                      .textTheme
                                      .body2
                                      .copyWith(color:Colors.white),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ]
                )
            ),
            Card(
                color: Colors.white,
                child: Column(
                    children: <Widget>[
                      SizedBox(
                        height: 180.0,
                        child: Stack(
                          children: <Widget>[
                            Positioned.fill(
                              child: Image.asset('lib/assets/images/inb.jpg',
                                fit: BoxFit.cover,
                              ),
                            ),
                            Positioned(
                              bottom: 16.0,
                              left: 16.0,
                              right: 16.0,
                              child: FittedBox(
                                fit: BoxFit.scaleDown,
                                alignment: Alignment.topLeft,
                                child: Text("£200 million investment, with a further £130 million to follow",
                                  style: Theme.of(context)
                                      .textTheme
                                      .body2
                                      .copyWith(color:Colors.white),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ]
                )
            ),
            Card(
                color: Colors.white,
                child: Column(
                    children: <Widget>[
                      SizedBox(
                        height: 180.0,
                        child: Stack(
                          children: <Widget>[
                            Positioned.fill(
                              child: Image.asset('lib/assets/images/inb.jpg',
                                fit: BoxFit.cover,
                              ),
                            ),
                            Positioned(
                              bottom: 16.0,
                              left: 16.0,
                              right: 16.0,
                              child: FittedBox(
                                fit: BoxFit.scaleDown,
                                alignment: Alignment.topLeft,
                                child: Text("Award winning campus, with all amenities in 1 location",
                                  style: Theme.of(context)
                                      .textTheme
                                      .body2
                                      .copyWith(color:Colors.white),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ]
                )
            ),
            Card(
                color: Colors.white,
                child: Column(
                    children: <Widget>[
                      SizedBox(
                        height: 180.0,
                        child: Stack(
                          children: <Widget>[
                            Positioned.fill(
                              child: Image.asset('lib/assets/images/inb.jpg',
                                fit: BoxFit.cover,
                              ),
                            ),
                            Positioned(
                              bottom: 16.0,
                              left: 16.0,
                              right: 16.0,
                              child: FittedBox(
                                fit: BoxFit.scaleDown,
                                alignment: Alignment.topLeft,
                                child: Text("Waterfront location, a short walk from the heart of Lincoln's city centre",
                                  style: Theme.of(context)
                                      .textTheme
                                      .body2
                                      .copyWith(color:Colors.white),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ]
                )
            )
          ],
        )
    );
  }
}