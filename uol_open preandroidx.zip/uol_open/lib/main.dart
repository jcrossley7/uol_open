import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:uol_open/pages/UpdatesPage.dart';
import 'package:uol_open/pages/MapPage.dart';
import 'package:uol_open/pages/WeatherPage.dart';
import 'package:uol_open/pages/AboutPage.dart';
import 'package:uol_open/pages/LibraryPage.dart';

void main() {
  runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: '/',
      routes: {
        '/': (context) => HomeScreen(),
        //'/maps': (context) => MapPage(),
        '/about': (context) => AboutPage(),
        '/updates': (context) => UpdatesPage(),
        //'/weather': (context) => WeatherPage(),
        '/library': (context) => LibraryPage()
      },
      theme: ThemeData(
          brightness: Brightness.dark,
          primaryColor: Color(0xFF002147),
          accentColor: Color(0xFF747678),
          fontFamily: 'GoudyModern',
          textTheme: TextTheme(
              headline: TextStyle(fontSize: 72.0, fontWeight: FontWeight.bold,),
              title: TextStyle(fontSize: 36.0, fontWeight: FontWeight.w600),
              body1: TextStyle(fontSize: 14.0, fontFamily: 'Helvetica'),
              body2: TextStyle(fontSize: 28.0, fontFamily: 'Helvetica')
          )
      )
  )
  );
}
class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('lib/assets/images/uniLogoLandscapeWhite.jpg',
              fit: BoxFit.contain,
              height: 32.0,
            ),
            Container(
              padding: const EdgeInsets.all(8.0), child: Text('Open Days'),
            )
          ],
        ),
      ),
      drawer: Drawer(
          child: ListView(
              children: <Widget>[
                ListTile(
                  title: Text("Map"),
                  trailing: Icon(Icons.map),
                 /** onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => MapPage()),
                    );
                  },**/
                ),
                ListTile(
                  title: Text("Updates"),
                  trailing: Icon(Icons.alternate_email),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => UpdatesPage()),
                    );
                  },
                ),
                ListTile(
                  title: Text("Weather"),
                  trailing: Icon(Icons.wb_sunny),
                  /**onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => WeatherPage()),
                    );
                  },**/
                ),
                ListTile(
                    title: Text("About University of Lincoln"),
                    trailing: Icon(Icons.info_outline),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => AboutPage()),
                      );
                    }
                ),
                ListTile(
                    title: Text("GCW - University Library"),
                    trailing: Icon(Icons.book),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => LibraryPage()),
                      );
                    }
                )
              ]
          )
      ),
      body: new Container(
        decoration: new BoxDecoration(
          image: new DecorationImage(
            image: new AssetImage("lib/assets/images/inb.jpg"),
            fit: BoxFit.cover,
          ),
        ),
        child: null,
      ),
    );
    /**/
  }
}
